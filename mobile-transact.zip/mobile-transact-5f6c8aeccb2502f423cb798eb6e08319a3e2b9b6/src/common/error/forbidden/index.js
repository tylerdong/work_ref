import React from 'react'

export default props => {
  return (
    <div>无权限访问</div>
  )
}
