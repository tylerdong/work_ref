/**
 * 侧边菜单配置
 */
export default [
  // {
  //   key: 'index',
  //   value: '首页',
  //   icon: 'home',
  //   url: '/'
  // },
  // {
  //   key: 'user',
  //   value: '用户管理',
  //   icon: 'solution',
  //   url: '/user'
  // }
]

// 顶部菜单配置
export const topMenus = [
  // {
  //   key: 'home',
  //   value: '首页',
  //   icon: 'home',
  //   url: '/'
  // },
  // {
  //   key: 'user',
  //   value: '用户管理',
  //   icon: 'solution',
  //   url: '/user'
  // }
]
